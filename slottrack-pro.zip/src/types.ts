export interface Location {
  id: string;
  name: string;
}

export interface Machine {
  id: string;
  name: string;
  locationId: string;
}

export interface RecordEntry {
  id: string;
  timestamp: number;
  dateStr: string; // YYYY-MM-DD
  locationId: string;
  locationName: string;
  machineId?: string;
  machineName?: string;
  coinCount: number;
  coinValue: number;
  total: number;
  ownerShare: number; // 65%
  managerShare: number; // 35%
  notes: string;
}

export interface Settings {
  masterPassword?: string;
  theme: 'light' | 'dark';
}

export interface AppData {
  locations: Location[];
  machines: Machine[];
  records: RecordEntry[];
  settings: Settings;
}
