import React, { useState } from 'react';
import { useStore } from '../store';
import { generateId } from '../utils';
import { ReceiptModal } from './ReceiptModal';
import { Save, Calculator, Eraser } from 'lucide-react';
import { RecordEntry } from '../types';

export function NewRecord() {
  const { data, addRecord } = useStore();
  const [locationId, setLocationId] = useState('');
  const [coinCount, setCoinCount] = useState('');
  const [coinValue, setCoinValue] = useState('5'); // Default 5 per coin
  const [notes, setNotes] = useState('');
  
  // Format current date for datetime-local input
  const localIsoString = new Date(new Date().getTime() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 16);
  const [customDate, setCustomDate] = useState(localIsoString);
  
  const [savedRecord, setSavedRecord] = useState<RecordEntry | null>(null);

  const numCoins = parseInt(coinCount) || 0;
  const valCoin = parseInt(coinValue) || 0;
  const total = numCoins * valCoin;
  const ownerShare = total * 0.65;
  const managerShare = total * 0.35;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!locationId || numCoins <= 0 || valCoin <= 0) return;

    const locName = data.locations.find(l => l.id === locationId)?.name || 'Desconocido';
    const timestamp = customDate ? new Date(customDate).getTime() : Date.now();
    const date = new Date(timestamp);
    const dateStr = date.toISOString().split('T')[0];

    const record: RecordEntry = {
      id: generateId(),
      timestamp,
      dateStr,
      locationId,
      locationName: locName,
      coinCount: numCoins,
      coinValue: valCoin,
      total,
      ownerShare,
      managerShare,
      notes
    };

    addRecord(record);
    setSavedRecord(record);
    
    // Reset form
    setCoinCount('');
    setNotes('');
    setCustomDate(new Date(new Date().getTime() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 16));
  };

  const handleClear = () => {
    setLocationId('');
    setCoinCount('');
    setCoinValue('5');
    setNotes('');
    setCustomDate(new Date(new Date().getTime() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 16));
  };

  if (savedRecord) {
    return <ReceiptModal record={savedRecord} onClose={() => setSavedRecord(null)} />;
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold text-white">Nuevo Conteo</h1>
      
      <form onSubmit={handleSave} className="bg-slate-800/70 backdrop-blur-md p-6 rounded-3xl shadow-lg border border-white/10 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          <div className="space-y-2 lg:col-span-2">
            <label className="text-sm font-medium text-slate-300">Fecha y Hora (Opcional - Para historiales pasados)</label>
            <input 
              type="datetime-local"
              value={customDate}
              onChange={e => setCustomDate(e.target.value)}
              className="w-full p-3 rounded-xl border border-white/10 bg-slate-900 text-white focus:ring-2 focus:ring-blue-500 focus:outline-none focus:bg-slate-800 transition-colors"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-300">Puesto</label>
            <select 
              value={locationId} 
              onChange={e => setLocationId(e.target.value)}
              className="w-full p-3 rounded-xl border border-white/10 bg-slate-900 text-white focus:ring-2 focus:ring-blue-500 focus:outline-none focus:bg-slate-800 appearance-none"
              required
            >
              <option value="">Seleccione Puesto</option>
              {data.locations.map(loc => (
                <option key={loc.id} value={loc.id}>{loc.name}</option>
              ))}
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-300">Cantidad de Monedas</label>
            <input 
              type="number"
              min="1"
              value={coinCount}
              onChange={e => setCoinCount(e.target.value)}
              className="w-full p-3 rounded-xl border border-white/10 bg-white/5 text-white placeholder:text-slate-500 focus:ring-2 focus:ring-blue-500 focus:outline-none focus:bg-white/10 transition-colors"
              required
              placeholder="Ej. 1500"
            />
          </div>

          <div className="space-y-2 md:col-span-2">
            <label className="text-sm font-medium text-slate-300">Valor de la Moneda (Lempiras)</label>
            <input 
              type="number"
              min="1"
              value={coinValue}
              onChange={e => setCoinValue(e.target.value)}
              className="w-full p-3 rounded-xl border border-white/10 bg-white/5 text-white focus:ring-2 focus:ring-blue-500 focus:outline-none focus:bg-white/10 transition-colors"
              required
            />
          </div>

        </div>

        {/* Live Calculation Box */}
        <div className="bg-gradient-to-br from-slate-800 to-slate-900 border border-blue-500/50 rounded-2xl p-6 space-y-4 shadow-lg shadow-blue-500/10 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-full blur-3xl"></div>
          <div className="flex items-center gap-2 text-blue-400 font-semibold mb-2 border-b border-white/10 pb-3 relative z-10">
            <Calculator size={18} /> Resumen Calculado
          </div>
          
          <div className="flex justify-between items-center text-sm relative z-10">
            <span className="text-slate-400">Total Recaudado</span>
            <span className="font-bold text-white text-xl">L {total.toLocaleString()}</span>
          </div>
          <div className="flex justify-between items-center text-sm relative z-10">
            <span className="text-slate-400">Me quedan (65%)</span>
            <span className="font-bold text-emerald-400 text-lg">L {ownerShare.toLocaleString()}</span>
          </div>
          <div className="flex justify-between items-center text-sm relative z-10">
            <span className="text-slate-400">Dejar al encargado (35%)</span>
            <span className="font-bold text-amber-400 text-lg">L {managerShare.toLocaleString()}</span>
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium text-slate-300">Observaciones (Opcional)</label>
          <textarea 
            value={notes}
            onChange={e => setNotes(e.target.value)}
            className="w-full p-3 rounded-xl border border-white/10 bg-white/5 text-white placeholder:text-slate-500 focus:ring-2 focus:ring-blue-500 focus:outline-none resize-none focus:bg-white/10 transition-colors"
            rows={2}
            placeholder="Algún detalle especial sobre el conteo..."
          />
        </div>

        <div className="flex gap-4">
          <button 
            type="button"
            onClick={handleClear}
            className="w-1/3 bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 font-medium py-4 rounded-xl shadow-lg transition-colors flex justify-center items-center gap-2"
          >
            <Eraser size={20} />
            Limpiar
          </button>
          
          <button 
            type="submit"
            disabled={!locationId || numCoins <= 0 || valCoin <= 0}
            className="w-2/3 bg-blue-600 hover:bg-blue-500 border border-transparent disabled:border-white/10 disabled:bg-white/5 disabled:text-slate-500 disabled:cursor-not-allowed text-white font-medium py-4 rounded-xl shadow-lg shadow-blue-500/20 transition-colors flex justify-center items-center gap-2 text-lg"
          >
            <Save size={20} />
            Guardar
          </button>
        </div>

      </form>
    </div>
  );
}
