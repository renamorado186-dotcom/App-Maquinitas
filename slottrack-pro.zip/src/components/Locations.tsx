import React, { useState } from 'react';
import { useStore } from '../store';
import { generateId } from '../utils';
import { MapPin, Plus, Edit2, Trash2 } from 'lucide-react';

export function Locations() {
  const { data, addLocation, updateLocation, deleteLocation } = useStore();
  
  const [newLocName, setNewLocName] = useState('');
  
  const [editingLoc, setEditingLoc] = useState<string | null>(null);
  const [editLocName, setEditLocName] = useState('');

  const handleAddLocation = (e:React.FormEvent) => {
    e.preventDefault();
    if(!newLocName.trim()) return;
    addLocation({ id: generateId(), name: newLocName.trim() });
    setNewLocName('');
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-white">Administrar Puestos y Máquinas</h1>
        <p className="text-slate-400 text-sm">Agrega, edita o elimina lugares y dispositivos</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        
        {/* === PUESTOS === */}
        <section className="bg-slate-800/70 backdrop-blur-md rounded-3xl shadow-lg border border-white/10 overflow-hidden flex flex-col lg:col-span-2">
          <div className="bg-white/5 p-4 border-b border-white/10 flex items-center gap-2">
            <div className="p-2 bg-blue-500/20 text-blue-400 rounded-lg"><MapPin size={18} /></div>
            <h2 className="font-semibold text-white">Puestos Registrados</h2>
          </div>

          <div className="p-4 flex-1">
            <ul className="space-y-3 mb-6">
              {data.locations.map(loc => (
                <li key={loc.id} className="flex items-center justify-between p-3 rounded-xl border border-white/10 hover:border-white/20 transition-colors bg-white/5">
                  {editingLoc === loc.id ? (
                    <div className="flex flex-1 gap-2">
                      <input 
                        type="text"
                        value={editLocName}
                        onChange={e => setEditLocName(e.target.value)}
                        className="flex-1 p-1 px-2 border border-blue-500/50 bg-slate-900 text-white rounded focus:outline-none focus:ring-1 focus:ring-blue-500"
                        autoFocus
                      />
                      <button onClick={() => { updateLocation(loc.id, editLocName); setEditingLoc(null); }} className="text-emerald-400 font-medium px-2">OK</button>
                      <button onClick={() => setEditingLoc(null)} className="text-slate-500 hover:text-slate-300">Cancel</button>
                    </div>
                  ) : (
                    <>
                      <span className="font-medium text-slate-200">{loc.name}</span>
                      <div className="flex gap-1 text-slate-500">
                        <button onClick={() => { setEditingLoc(loc.id); setEditLocName(loc.name); }} className="p-2 hover:text-blue-400 rounded"><Edit2 size={16}/></button>
                        <button onClick={() => { if(window.confirm('¿Seguro que deseas eliminar este puesto?')) deleteLocation(loc.id)}} className="p-2 hover:text-rose-400 rounded"><Trash2 size={16}/></button>
                      </div>
                    </>
                  )}
                </li>
              ))}
            </ul>

            <form onSubmit={handleAddLocation} className="flex gap-2">
              <input 
                type="text" 
                placeholder="Nombre del nuevo puesto..."
                value={newLocName}
                onChange={e => setNewLocName(e.target.value)}
                className="flex-1 p-3 bg-white/5 border border-white/10 text-white placeholder:text-slate-500 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none focus:bg-slate-800 transition-colors"
              />
              <button disabled={!newLocName.trim()} type="submit" className="bg-blue-600 hover:bg-blue-500 transition-colors text-white px-4 rounded-xl disabled:opacity-50 disabled:bg-white/5 disabled:border disabled:border-white/10 disabled:text-slate-500">
                <Plus size={20} />
              </button>
            </form>
          </div>
        </section>

      </div>
    </div>
  );
}
